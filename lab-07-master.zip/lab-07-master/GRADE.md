Dear Student,

I'm happy to announce that you've managed to get **11** out of 11 points for this assignment.
You should be proud of yourself; therefore please deliver yourself a [self-five](https://youtu.be/kMUkzWO8viY) on my behalf as I am not a corporeal being.

-----------
I remain your faithful servant\
_Bobot_