Dear Student,

I'm happy to announce that you've managed to get **30** out of 30 points for this assignment.
Me and all the virtual entities [salute you](https://tenor.com/xtvD.gif).

-----------
I remain your faithful servant\
_Bobot_