from ..solver import Solver
from ..model import Solution, Item
import numpy as np
from typing import List



class DynamicSolver(Solver):
    """
    A naive dynamic programming solver for the knapsack problem.
    """

    def _create_table(self) -> np.ndarray:
        # TODO: fill the table!
        # tip 1. init table using np.zeros function (replace `None``)
        # tip 2. remember to handle timeout (refer to the dfs solver for an example)
        #        - just return the current state of the table

        tab = np.zeros((self.problem.capacity + 1, len(self.problem.items) + 1))
        column = 1

        for item in self.problem.items:
            for i in range(tab.shape[0]):
                if self.timeout():
                    return tab
                if item.weight > i:
                    tab[i][column] = tab[i][column - 1]
                else:
                    tab[i][column] = max(tab[i - item.weight][column - 1] + item.value, tab[i][column - 1])
            column += 1


        return tab

    def _extract_solution(self, table: np.ndarray) -> Solution:
        used_items: List[Item] = []
        optimal = table[-1, -1] > 0
        x = table.shape[0] - 1
        y = table.shape[1] - 1
        while x and y:
            if table[x][y - 1] != table[x][y]:
                used_items.append(self.problem.items[y-1])
                x = x - self.problem.items[y-1].weight
            y = y-1

        # TODO: fill in the `used_items` list using info from the table!

        return Solution.from_items(used_items, optimal)

    def solve(self) -> Solution:
        self.interrupted = False
        self.start_timer()

        table = self._create_table()
        solution = self._extract_solution(table) if table is not None else Solution.empty()

        self.stop_timer()
        return solution
