from ..model import Project
from ..project_network import ProjectNetwork
from ...simplex.model import Model
from ...simplex.expressions.expression import Expression
from ...simplex.expressions.expression import Atom
from ..solution import BasicSolution
from ...simplex.expressions.constraint import Constraint
from ...simplex.expressions.constraint import ConstraintType
class Solver:
    '''
    Simplex based solver looking for the critical path in the project.
    Uses linear model maximizing length of the path in the project network. 

    Attributes:
    ----------
    project_network: ProjectNetwork
        a project network related to the given project
    model: simplex.model.Model
        a linear model looking for the maximal path in the project network
    Methods:
    --------
    __init__(problem: Project)
        create a solver for the given project
    create_model() -> simplex.model.Model
        builds a linear model of the problem
    solve() -> BasicSolution
        finds the duration of the critical (longest) path in the project network
    '''
    def __init__(self, problem: Project):
        self.project_network = ProjectNetwork(problem)
        self.model = self.create_model()

    def create_model(self) -> Model:
        # TODO:
        # 0) we need as many variables as there are edges in the project network
        # 1) every variable has to be <= 1
        # 2) sum of the variables starting at the initial state has to be equal 1
        # 3) sum of the variables ending at the goal state has to be equal 1
        # 4) for every other node, total flow going trough it has to be equal 0
        #    i.e. sum of incoming arcs minus sum of the outgoing arcs = 0
        # 5) we have to maximize length of the path
        #    (sum of variables weighted by the durations of the corresponding tasks)
        #
        # tip 1. `self.project_network` is the project network you should use
        #        - read documentation of ProjectNetwork class in 
        #          `saport/critical_path/project_network.py` for guidance
        model = Model("critical path (max)")
        variables = dict()
        for edge in self.project_network.edges():
            variables[tuple([edge[0].index, edge[1].index])] = model.create_variable(f"x{edge[0].index}{edge[1].index}")
        for edge in self.project_network.edges():
            model.add_constraint(variables[tuple([edge[0].index, edge[1].index])] <= 1)
            model.add_constraint(variables[tuple([edge[0].index, edge[1].index])] >= 0)

        obj = Expression()
        for edge in self.project_network.edges():
            x = Atom(variables[tuple([edge[0].index, edge[1].index])], edge[2].duration)
            obj = obj.__add__(x)
        model.maximize(obj)

        con1 = Expression()
        conlast = Expression()
        for edge in self.project_network.edges():
            if edge[0].index == 1:
                x = Atom(variables[tuple([edge[0].index, edge[1].index])], 1)
                con1 = con1.__add__(x)
            if edge[1] == self.project_network.goal_node.index:
                x = Atom(variables[tuple([edge[0].index, edge[1].index])], 1)
                conlast = conlast.__add__(x)
        const1 = Constraint(con1, 1, ConstraintType.EQ)
        model.add_constraint(const1)
        constlast = Constraint(conlast,  1, ConstraintType.EQ)
        model.add_constraint(constlast)

        for node in self.project_network.nodes():
            if node.index != self.project_network.start_node.index and node.index != self.project_network.goal_node.index:
                exp = Expression()
                for edge in self.project_network.edges():
                    if edge[0].index == node.index:
                        x = Atom(variables[tuple([edge[0].index, edge[1].index])], -1)
                        exp = exp.__add__(x)
                    if edge[1].index == node.index:
                        x = Atom(variables[tuple([edge[0].index, edge[1].index])], 1)
                        exp = exp.__add__(x)
                const = Constraint(exp, 0, ConstraintType.EQ)
                model.add_constraint(const)

        return model

    def solve(self) -> BasicSolution:
        solution = self.model.solve()
        return BasicSolution(int(solution.objective_value()))
