Dear Student,

I'm happy to announce that you've managed to get **10** out of 10 points for this assignment.
<details><summary>You have already managed to pass 6 tests, so that is encouraging!</summary>&emsp;☑&nbsp;[2p] Solver properly adds artificial variables<br>&emsp;☑&nbsp;[2p] Solver properly presolves initial tableau<br>&emsp;☑&nbsp;[2p] Solver should properly checks if art vars positive<br>&emsp;☑&nbsp;[2p] Solver properly restores initial tableau<br>&emsp;☑&nbsp;[1p] Example 04 finds correct solution<br>&emsp;☑&nbsp;[1p] Example 05 should be infeasible</details>
There is nothing more to say, just please receive my [congratulations](https://youtu.be/1Bix44C1EzY).

-----------
I remain your faithful servant\
_Bobot_