import logging
from saport.simplex.model import Model 

from saport.simplex.model import Model

def create_model() -> Model:
    model = Model("example_05_infeasible")
    # TODO:
    # fill missing test based on the example_03_unbounded.py
    # to make the test a bit more interesting:
    # * make sure model is infeasible

    x1 = model.create_variable("x1")
    x2 = model.create_variable("x2")
    x3 = model.create_variable("x3")
    x4 = model.create_variable("x4")

    
    model.add_constraint(x1 + x2 >= -200)
    model.add_constraint(x2 + 3*x4 >= -100)
    model.add_constraint(3*x2 + x3 <= -400)
    model.add_constraint(2*x1 + x4 <= -500)
    
    model.minimize(8 * x1 + 5 * x2 + 3 * x3 + 2 *x4)


    return model

def run():
    model = create_model()
    # TODO:
    # add a test "assert something" based on the example_03_unbounded.py
    # TIP: you may use other solvers (e.g. https://online-optimizer.appspot.com)
    #      to find the correct solution
    
    def run():
        model = create_model()

        solution = model.solve()
        if solution.is_bounded:
            raise AssertionError("Your algorithm found a solution to an unbounded problem. This shouldn't happen...")
        else:
            logging.info("Congratulations! This problem is unbounded and your algorithm has found that :)")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    run()
